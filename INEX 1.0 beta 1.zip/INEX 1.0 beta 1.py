import webbrowser
url=input('您要打开哪个网址？(例：https://www.baidu.com)')
webbrowser.open(url)

